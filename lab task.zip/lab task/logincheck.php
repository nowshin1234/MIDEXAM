<?php
if(isset($_Post['submit'])
{
	$name=$_POST['name'];
	$password=$_POST['password'];
	if(empty($name)== true || empty($password)
	{echo "null";}
else
{
	if($name==$password)
	{
		echo "valid";
	}
	else
	{echo "invalid";}
}
}
else {echo "invalid user";}	


?>